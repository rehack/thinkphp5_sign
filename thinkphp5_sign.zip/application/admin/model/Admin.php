<?php
namespace app\admin\model;
use think\Model;

// 管理员模型
class Admin extends Model{

}
