<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:77:"E:\mygit\thinkphp5_sign\public/../application/admin\view\useradd\useradd.html";i:1480650160;s:80:"E:\mygit\thinkphp5_sign\public/../application/admin\view\Public\userAddForm.html";i:1480650142;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>新增客户</title>
    <link rel="stylesheet" href="__PUBLIC__static/bootstrap/css/bootstrap.full.css">
    <link rel="stylesheet" href="__PUBLIC__static/bootstrap/css/bootstrap-datepicker.min.css">
    <script src="__PUBLIC__static/easyui/js/jquery.min.js" type="text/javascript"></script>
    <script src="__PUBLIC__static/bootstrap/js/bootstrap.min.js"></script>
    <script src="__PUBLIC__static/bootstrap/js/bootstrap-datepicker.min.js"></script>
    <script src="__PUBLIC__static/bootstrap/js/bootstrap-datepicker.zh-CN.min.js"></script>
    <style>
        .form-group{padding-bottom: 15px;}
        .control-label{text-align: right;/* width: 20%; */margin-right: 2%;}
        .form-control{width: 60%!important;}
        .line{border-bottom: 1px dashed #ccc;text-align: center;color: #888;margin-bottom: 20px;}
        /* .btns{text-align: center;} */
        #msg{color: #f00;}
        .close{display: none;}
    </style>
</head>

<body>

    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel"><span class="glyphicon glyphicon-user"></span>用户基本信息</h4>
      </div>
      <div class="modal-body">
        <form action="" method="post" class="form-inline" role="form" id="formdata">
            <div class="row">
                <div class="col-md-12 form-group">
                    <label class="control-label" for="name">姓&emsp;&emsp;名</label>
                    <input class="form-control" id="name" type="text" name="name" placeholder="姓名" required1="required" />
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 form-group">
                    <label class="control-label" for="sex">性&emsp;&emsp;别</label>
                    <select class="form-control" id="sex" name="sex">
                        <option value="">未知</option>
                        <option value="1">男</option>
                        <option value="2">女</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 form-group">
                    <label class="control-label" for="telephone">手机号码</label>
                    <input class="form-control" id="telephone" type="tel" placeholder="手机号" required1="required" name="telephone" />
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 form-group">
                    <label class="control-label" for="comment">备&emsp;&emsp;注</label>
                    <textarea id="comment" class="form-control" name="comment" rows="3" required1="required"></textarea>
                </div>
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <b id="msg" class="pull-left"></b><br>
        <button type="submit" id="submit" class="btn btn-success">保存</button>
        <button type="reset" class="btn btn-warning">重置</button>
        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="addUserDialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">新客户添加成功！</div>
            <div class="modal-footer">
                <span class="pull-left text-danger" id="addconmsg"></span>
                <button type="button" class="btn btn-default" data-dismiss="modal">确定</button>
                <!-- <button type="button" class="btn btn-primary" id="secAddCon">继续添加</button> -->
            </div>
        </div>
    </div>
</div>


    <script>
		$(function() {
		    $('#myModal').modal({
		        backdrop: false,
		    });
		    $('#submit').on('click', function() {
		        $.ajax({
	                url: '<?php echo url("useradd"); ?>?r='+Math.random(),
	                type: 'POST',
	                dataType: 'html',
	                data: $('#formdata').serialize()
	            })
	            .done(function(data) {
	                // console.log(data);
	                $('#msg').html('提示信息：' + data);
	                if (data == '"客户添加成功!"') {
	                    $('#submit').attr('disabled', true);
	                    $('#formdata').get(0).reset();
	                    $('#msg').html('');
	                    // $('#myModal').modal('hide');
	                    $('#addUserDialog').modal();
	                    $('#submit').attr('disabled', false);
	                }
	            })
	            .fail(function() {
	                alert("发生错误");
	            });

		        return false;

		    })
		})
	</script>

</body>

</html>
