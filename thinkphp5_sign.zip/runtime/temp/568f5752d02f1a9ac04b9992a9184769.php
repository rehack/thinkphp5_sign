<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:74:"E:\phpstudyfiles\qiandao\public/../application/admin\view\index\index.html";i:1480584012;s:73:"E:\phpstudyfiles\qiandao\public/../application/admin\view\Public\top.html";i:1480585024;s:74:"E:\phpstudyfiles\qiandao\public/../application/admin\view\Public\left.html";i:1480820737;s:75:"E:\phpstudyfiles\qiandao\public/../application/admin\view\Public\right.html";i:1480557317;s:76:"E:\phpstudyfiles\qiandao\public/../application/admin\view\Public\footer.html";i:1480557317;}*/ ?>
<!DOCTYPE html>
<html>
<head id="Head1">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>成都贝臣齿科客户签到管理系统</title>
    <!-- <link href="__PUBLIC__static/css/default.css" rel="stylesheet" type="text/css" /> -->
    <link href="__PUBLIC__static/easyui/css/easyui.css" rel="stylesheet" type="text/css" />
    <link href="http://cdn.bootcss.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="__PUBLIC__static/bootstrap/css/bootstrap.full.css"> -->
    <!-- <script src="__PUBLIC__static/bootstrap/js/bootstrap.min.js"></script> -->
    <script src="__PUBLIC__static/easyui/js/jquery.min.js" type="text/javascript"></script>
    <script src="__PUBLIC__static/easyui/js/jquery.easyui.min.js" type="text/javascript"></script>
    <script src="__PUBLIC__static/easyui/js/easyui-lang-zh_CN.js" type="text/javascript"></script>
    <style>
        .alert-danger{color: #a94442;background-color: #f2dede;border-color: #ebccd1;border: 1px solid transparent;border-radius: 4px;padding: 15px;font-size: 14px;}
    </style>
</head>

<body class="easyui-layout" style="overflow-y: hidden" scroll="no">
    <noscript>
        <div style=" position:absolute; z-index:100000; height:2046px;top:0px;left:0px; width:100%; background:white; text-align:center;"> <img src="__PUBLIC__static/images/noscript.gif" alt='抱歉，请开启脚本支持！' /> </div>
    </noscript>
    <div region="north" split="true" border="false" style="overflow: hidden;height: 40px;background: #2dc3e8;line-height: 40px;color: #fff; font-family: Verdana, 微软雅黑,黑体">
    <span style="float:right; padding-right:20px;" class="head">欢迎 <?php echo \think\Request::instance()->session('user_name'); ?>
    	<span id="clear" style="cursor: pointer;">清除缓存</span>
        <a href="<?php echo url('Login/logout'); ?>" id="loginOut">安全退出</a>
    </span>
    <span style="padding-left:10px; font-size: 16px;">
        <i class="fa fa-cogs" aria-hidden="true" style="color: #fff;"></i>
    	成都贝臣齿科客户签到管理系统
    </span>
</div>
<script>
    $('#clear').on('click',function(){
        $.ajax({
            url: "<?php echo url('Login/clear'); ?>",
            type: 'POST',
            dataType: 'html',
            // data: {param1: 'value1'},
        })
        .done(function(data) {
            alert(data);
        })
        .fail(function() {
            alert("发生错误");
        });

    })
</script>

    <div data-options="region:'west',split:true" title="导航菜单" style="width:150px;">
    <div class="easyui-accordion" data-options="fit:false,border:false">
        <?php if(is_array($json) || $json instanceof \think\Collection): $i = 0; $__LIST__ = $json;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <div title="<?php echo $vo['menuname']; ?>" style="padding:10px;" class="">
            <?php foreach($vo['menus'] as $child): ?>
            <a id="menu<?php echo $child['id']; ?>" class="easyui-linkbutton" onclick="addTab('<?php echo $child['menuname']; ?>','<?php echo $child['url']; ?>')" plain="true"><?php echo $child['menuname']; ?></a><br>
            <?php endforeach; ?>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div>
<script>
    function addTab(title, url){
        if ($('#tabs').tabs('exists', title)){
            $('#tabs').tabs('select', title);
        } else {
            var content = '<iframe scrolling="auto" frameborder="0"  src="'+url+'" style="width:100%;height:100%;"></iframe>';
            $('#tabs').tabs('add',{
                title:title,
                content:content,
                closable:true
            });
        }
    }
</script>

    <div id="mainPanle" region="center" style="background: #eee; overflow-y:hidden">
        <div id="tabs" class="easyui-tabs" fit="true" border="false" style="overflow:hidden">
            <div title="欢迎使用" style="padding:10px;overflow:hidden; color:red; ">
                <div class="alert alert-danger" role="alert">您好，<?php echo session('user_name')?>，欢迎使用成都贝臣齿科客户签到管理系统,您当前的登录ip：<?php echo \think\Request::instance()->ip(); ?> 请使用Chrome、Firefox等现代浏览器操作本系统！</div>
            </div>
        </div>
    </div>
    <!-- <div region="east" title="其他" split="true" style="width:180px;overflow:hidden;">
    <div class="easyui-calendar"></div>
    <p>1</p>
</div> -->
    <div region="south" split="true" style="height: 30px; background: #D2E0F2; text-align: center; ">
    <div class="footer">成都贝臣版权所有，翻版必究 Copyright &copy;2014-2016 v1.0内测</div>
</div>
    <!--修改密码窗口-->
    <!-- <div id="w" class="easyui-window" title="修改密码" collapsible="false" minimizable="false" maximizable="false" icon="icon-save" style="width: 300px; height: 150px; padding: 5px;
        background: #fafafa;">
        <div class="easyui-layout" fit="true">
            <div region="center" border="false" style="padding: 10px; background: #fff; border: 1px solid #ccc;">
                <table cellpadding=3>
                    <tr>
                        <td>新密码：</td>
                        <td>
                            <input id="txtNewPass" type="Password" class="txt01" />
                        </td>
                    </tr>
                    <tr>
                        <td>确认密码：</td>
                        <td>
                            <input id="txtRePass" type="Password" class="txt01" />
                        </td>
                    </tr>
                </table>
            </div>
            <div region="south" border="false" style="text-align: right; height: 30px; line-height: 30px;"> <a id="btnEp" class="easyui-linkbutton" icon="icon-ok" href="javascript:void(0)"> 确定</a> <a id="btnCancel" class="easyui-linkbutton" icon="icon-cancel" href="javascript:void(0)">取消</a> </div>
        </div>
    </div>
    <div id="mm" class="easyui-menu" style="width:150px;">
        <div id="mm-tabupdate">刷新</div>
        <div class="menu-sep"></div>
        <div id="mm-tabclose">关闭</div>
        <div id="mm-tabcloseall">全部关闭</div>
        <div id="mm-tabcloseother">除此之外全部关闭</div>
        <div class="menu-sep"></div>
        <div id="mm-tabcloseright">当前页右侧全部关闭</div>
        <div id="mm-tabcloseleft">当前页左侧全部关闭</div>
        <div class="menu-sep"></div>
        <div id="mm-exit">退出</div>
    </div> -->


</body>

</html>
