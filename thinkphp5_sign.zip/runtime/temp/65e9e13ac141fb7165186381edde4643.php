<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"F:\phpstudyfile\qiandao\public/../application/admin\view\login\index.html";i:1480584037;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>客户签到管理系统-登录界面</title>
<link href="__PUBLIC__static/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- <script src="__PUBLIC__static/js/jquery-1.12.4.min.js" type="text/javascript"></script> -->
<script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
<script src="__PUBLIC__static/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</head>
<body>
	<div class="modal" id="loginModal">
	    <div class="modal-dialog modal-sm">
	        <div class="modal-content">
	            <div class="modal-header">
	                <!-- <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button> -->
	                <h4 class="modal-title">管理员登录</h4>
	            </div>
	            <form role="form" id="loginForm">
	                <div class="modal-body">
	                    <div class="form-group">
	                        <label for="username">用户名</label>
	                        <input type="text" class="form-control" name="username" id="username" placeholder="User name" required>
	                    </div>
	                    <div class="form-group">
	                        <label for="password">密码</label>
	                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
	                    </div>
	                    <div class="form-group">
	                        <label for="code">验证码</label>
	                        <input type="text" class="form-control" name="code" id="code" placeholder="Captcha" required>
	                        <img src="<?php echo captcha_src(); ?>" alt="captcha" title="点击更换" onclick="this.src='<?php echo captcha_src(); ?>'" id="verify" />
	                    </div>
	                </div>
	                <div class="modal-footer">
	                    <span class="text-danger pull-left" id="msg"></span>
	                    <button type="submit" class="btn btn-primary" id="loginBtn">登录</button>
	                </div>
	            </form>
	        </div>
	    </div>
	</div>
	<script>
	$('#loginModal').modal({'backdrop':false});
	// $(function(){
		$('#loginBtn').on('click',function(){
			if($('#username').val()==''||$('#password').val()==''||$('#code').val()==''){
				$('#msg').html('用户名、密码、验证码必填！');
				return false;
			}
			$.ajax({
				// url: '<?php echo url('Login/check'); ?>?r='+Math.random(),
				url: "<?php echo url('Login/check'); ?>",
				type: 'POST',
				dataType: 'json',
				data: $('#loginForm').serialize()
			})
			.done(function(data) {
				if(data.code==1){
				    window.location= "<?php echo url('Index/index'); ?>";
				}else{
					$('#verify').click();
				    $('#msg').html(data.msg);
				}

			})
			.fail(function() {
				$('#msg').html('error,发生错误请及时联系管理员!');
			});
			return false;
		});


	// })
	//回车提交表单
	$(document).keyup(function(e) {
		if (e.keyCode == 13) {
            $('#loginBtn').trigger("click");
        }
	});

	</script>
</body>
</html>
